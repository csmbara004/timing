#ifndef KTH_LARGEST
#define KTH_LARGEST

/**
 * Finds the kth largest value in an array.
 */
int kthLargest (int* array,  int N, int k);


#endif
